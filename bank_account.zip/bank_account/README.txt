============================================================
BANK ACCOUNT OPENING SYSTEM (WITH DATABASE)
============================================================
Flask + SQLite based bank account system.
============================================================

------------------------------------------------------------
PROJECT DETAILS
------------------------------------------------------------
Project Name : Bank Account System
Type         : Type B (Database version)
Day          : Day 9 of 12 Basic Projects Challenge
Created By   : Abhijit Suryawanshi
Date         : October 2026

------------------------------------------------------------
SPECIAL FEATURE
------------------------------------------------------------
Auto-generates a unique 10-digit account number 
for every new account!

------------------------------------------------------------
FEATURES
------------------------------------------------------------
- Account opening form with KYC details
- Auto-generate Account Number
- Save data in SQLite database
- Confirmation page showing Account Number
- View all accounts
- Search by name, account no, or phone
- Delete accounts

------------------------------------------------------------
HOW TO RUN
------------------------------------------------------------
1. cd bank_account
2. python -m venv venv
3. .\venv\Scripts\Activate.ps1
4. pip install flask
5. python app.py
6. Open: http://127.0.0.1:5000

------------------------------------------------------------
12-DAY CHALLENGE PROGRESS
------------------------------------------------------------
Day 01  Employee Info       COMPLETED
Day 02  Student Info        COMPLETED
Day 03  Patient Info        COMPLETED
Day 04  Book Info           COMPLETED
Day 05  Vehicle Info        COMPLETED
Day 06  Hotel Booking       COMPLETED
Day 07  Event Registration  COMPLETED
Day 08  Job Application     COMPLETED
Day 09  Bank Account        CURRENT
Day 10  Restaurant Order    UPCOMING
Day 11  Mobile Shop         UPCOMING
Day 12  Movie Ticket        UPCOMING

------------------------------------------------------------
AUTHOR
------------------------------------------------------------
Name     : Abhijit Suryawanshi
Project  : ABHI IT PROJECTS
Year     : 2026

============================================================
END OF README
============================================================