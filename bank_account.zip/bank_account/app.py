from flask import Flask, render_template, request, redirect, url_for, flash
import database

web = Flask(__name__)
web.secret_key = 'bank-secret-key-2026'

database.init_db()


# ============================================================
# ROUTE 1 — Bank Account Form
# ============================================================
@web.route('/')
@web.route('/bank')
def bank_form():
    return render_template('bank_form.html')


# ============================================================
# ROUTE 2 — Confirmation + Save
# ============================================================
@web.route('/bank/confirm', methods=['POST'])
def bank_confirm():
    if request.method == 'POST':
        full_name       = request.form.get("full_name")
        dob             = request.form.get("dob")
        gender          = request.form.get("gender")
        aadhar          = request.form.get("aadhar")
        pan             = request.form.get("pan")
        phone           = request.form.get("phone")
        email           = request.form.get("email")
        address         = request.form.get("address")
        account_type    = request.form.get("account_type")
        opening_balance = request.form.get("opening_balance")

        # Save to database (returns auto-generated account number)
        account_number = database.add_account(
            full_name=full_name,
            dob=dob,
            gender=gender,
            aadhar=aadhar,
            pan=pan,
            phone=phone,
            email=email,
            address=address,
            account_type=account_type,
            opening_balance=float(opening_balance) if opening_balance else 0
        )

        flash(f'Account successfully opened! 🏦 Account No: {account_number}', 'success')

        return render_template(
            'bank_confirm.html',
            account_number=account_number,
            full_name=full_name,
            dob=dob,
            gender=gender,
            aadhar=aadhar,
            pan=pan,
            phone=phone,
            email=email,
            address=address,
            account_type=account_type,
            opening_balance=opening_balance
        )

    return render_template('bank_form.html')


# ============================================================
# ROUTE 3 — Accounts List
# ============================================================
@web.route('/accounts')
def accounts_list():
    search = request.args.get('search', '').strip()
    accounts = database.get_all_accounts(search or None)
    return render_template('accounts_list.html', accounts=accounts, search=search)


# ============================================================
# ROUTE 4 — Delete Account
# ============================================================
@web.route('/accounts/delete/<int:id>', methods=['POST'])
def delete_account(id):
    database.delete_account(id)
    flash('Account closed/deleted.', 'success')
    return redirect(url_for('accounts_list'))


if __name__ == '__main__':
    web.run(debug=True)