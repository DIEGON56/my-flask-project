import sqlite3
import random
import string

DB_NAME = 'bank.db'


def get_connection():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """accounts table तयार करा."""
    conn = get_connection()
    conn.execute('''
        CREATE TABLE IF NOT EXISTS accounts (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            account_number  TEXT UNIQUE NOT NULL,
            full_name       TEXT NOT NULL,
            dob             TEXT NOT NULL,
            gender          TEXT NOT NULL,
            aadhar          TEXT NOT NULL,
            pan             TEXT,
            phone           TEXT NOT NULL,
            email           TEXT,
            address         TEXT NOT NULL,
            account_type    TEXT NOT NULL,
            opening_balance REAL,
            opened_at       TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()
    print("✅ Bank database तयार झाला!")


# ---------- Auto-Generate Account Number ----------
def generate_account_number():
    """10 digit random account number तयार करा."""
    return ''.join(random.choices(string.digits, k=10))


# ---------- CREATE ----------
def add_account(full_name, dob, gender, aadhar, pan, phone, email, address, account_type, opening_balance):
    # Unique account number generate करा
    while True:
        acc_no = generate_account_number()
        conn = get_connection()
        existing = conn.execute('SELECT id FROM accounts WHERE account_number = ?', (acc_no,)).fetchone()
        conn.close()
        if not existing:
            break

    conn = get_connection()
    conn.execute('''
        INSERT INTO accounts
        (account_number, full_name, dob, gender, aadhar, pan, phone, email, address, account_type, opening_balance)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (acc_no, full_name, dob, gender, aadhar, pan, phone, email, address, account_type, opening_balance))
    conn.commit()
    conn.close()
    return acc_no


# ---------- READ (all) ----------
def get_all_accounts(search=None):
    conn = get_connection()
    if search:
        pattern = f'%{search}%'
        rows = conn.execute('''
            SELECT * FROM accounts
            WHERE full_name LIKE ? OR account_number LIKE ? OR phone LIKE ?
            ORDER BY id DESC
        ''', (pattern, pattern, pattern)).fetchall()
    else:
        rows = conn.execute('SELECT * FROM accounts ORDER BY id DESC').fetchall()
    conn.close()
    return rows


# ---------- DELETE ----------
def delete_account(id):
    conn = get_connection()
    conn.execute('DELETE FROM accounts WHERE id = ?', (id,))
    conn.commit()
    conn.close()