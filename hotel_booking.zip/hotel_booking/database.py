import sqlite3
from datetime import datetime

DB_NAME = 'hotel.db'


def get_connection():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    
    conn = get_connection()
    conn.execute('''
        CREATE TABLE IF NOT EXISTS bookings (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            guest_name      TEXT NOT NULL,
            phone           TEXT NOT NULL,
            email           TEXT,
            room_type       TEXT NOT NULL,
            check_in        TEXT NOT NULL,
            check_out       TEXT NOT NULL,
            total_guests    INTEGER NOT NULL,
            total_days      INTEGER,
            total_amount    REAL,
            special_request TEXT,
            booked_at       TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()
    print("✅ Hotel database Created !")


# ---------- CREATE ----------
def add_booking(guest_name, phone, email, room_type, check_in, check_out,
                total_guests, total_days, total_amount, special_request):
    conn = get_connection()
    conn.execute('''
        INSERT INTO bookings
        (guest_name, phone, email, room_type, check_in, check_out,
         total_guests, total_days, total_amount, special_request)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (guest_name, phone, email, room_type, check_in, check_out,
          total_guests, total_days, total_amount, special_request))
    conn.commit()
    conn.close()


# ---------- READ (all) ----------
def get_all_bookings(search=None):
    conn = get_connection()
    if search:
        pattern = f'%{search}%'
        rows = conn.execute('''
            SELECT * FROM bookings
            WHERE guest_name LIKE ? OR phone LIKE ? OR room_type LIKE ?
            ORDER BY id DESC
        ''', (pattern, pattern, pattern)).fetchall()
    else:
        rows = conn.execute('SELECT * FROM bookings ORDER BY id DESC').fetchall()
    conn.close()
    return rows


# ---------- DELETE ----------
def delete_booking(id):
    conn = get_connection()
    conn.execute('DELETE FROM bookings WHERE id = ?', (id,))
    conn.commit()
    conn.close()


# ---------- Helper — days calculate ----------
def calculate_days(check_in, check_out):
    try:
        d1 = datetime.strptime(check_in, '%Y-%m-%d')
        d2 = datetime.strptime(check_out, '%Y-%m-%d')
        days = (d2 - d1).days
        return max(0, days)
    except:
        return 0