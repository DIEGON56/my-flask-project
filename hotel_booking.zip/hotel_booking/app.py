from flask import Flask, render_template, request, redirect, url_for, flash
from datetime import datetime
import database

web = Flask(__name__)
web.secret_key = 'hotel-secret-key-2026'

database.init_db()

# ---------- Room Rates (₹ per day) ----------
ROOM_RATES = {
    'Single':  1500,
    'Double':  2500,
    'Suite':   5000,
    'Deluxe':  4000,
    'Family':  3500,
}



# ROUTE 1 — Booking Form

@web.route('/')
@web.route('/booking')
def booking_form():
    return render_template('booking_form.html', rates=ROOM_RATES)



# ROUTE 2 — Confirmation + Save

@web.route('/booking/confirm', methods=['POST'])
def booking_confirm():
    guest_name      = request.form.get("guest_name")
    phone           = request.form.get("phone")
    email           = request.form.get("email")
    room_type       = request.form.get("room_type")
    check_in        = request.form.get("check_in")
    check_out       = request.form.get("check_out")
    total_guests    = int(request.form.get("total_guests") or 1)
    special_request = request.form.get("special_request")

    # Days + Total amount calculate
    total_days = database.calculate_days(check_in, check_out)
    rate = ROOM_RATES.get(room_type, 0)
    total_amount = rate * total_days

    if total_days <= 0:
        flash('Check-out date after check-in !', 'error')
        return redirect(url_for('booking_form'))

    # Save to database
    database.add_booking(
        guest_name=guest_name,
        phone=phone,
        email=email,
        room_type=room_type,
        check_in=check_in,
        check_out=check_out,
        total_guests=total_guests,
        total_days=total_days,
        total_amount=total_amount,
        special_request=special_request
    )

    flash('Booking successfully saved! 🏨', 'success')

    return render_template(
        'booking_confirm.html',
        guest_name=guest_name,
        phone=phone,
        email=email,
        room_type=room_type,
        check_in=check_in,
        check_out=check_out,
        total_guests=total_guests,
        total_days=total_days,
        total_amount=total_amount,
        special_request=special_request
    )



# ROUTE 3 — Bookings List

@web.route('/bookings')
def bookings_list():
    search = request.args.get('search', '').strip()
    bookings = database.get_all_bookings(search or None)
    return render_template('bookings_list.html', bookings=bookings, search=search)



# ROUTE 4 — Delete Booking

@web.route('/bookings/delete/<int:id>', methods=['POST'])
def delete_booking(id):
    database.delete_booking(id)
    flash('Booking deleted.', 'success')
    return redirect(url_for('bookings_list'))


if __name__ == '__main__':
    web.run(debug=True)