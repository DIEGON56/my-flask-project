
HOTEL BOOKING SYSTEM (WITH DATABASE)

Flask + SQLite based hotel booking system.


PROJECT DETAILS
Project Name : Hotel Booking System
Type         : Type B (Database version)
Day          : Day 6 of 12 Basic Projects Challenge
Created By   : Abhijit Suryawanshi
Date         : October 2026

ABOUT PROJECT
A Flask web application where users can book hotel rooms.
The system calculates total days and amount automatically
based on check-in, check-out dates and room type.

All bookings are saved in an SQLite database.

TECHNOLOGY USED
- Python 3.10
- Flask 3.0
- SQLite (database)
- HTML5
- CSS3
- Jinja2
- datetime module (for calculations)

FEATURES
- Book hotel room with guest details
- Select room type (Single/Double/Suite/Deluxe/Family)
- Auto-calculate total days (check-out - check-in)
- Auto-calculate total amount (days × rate)
- Save booking permanently in database
- View all bookings in table
- Search bookings by guest/phone/room
- Delete bookings
- Data persists after restart

ROOM RATES
Single   : ₹ 1500 / day
Double   : ₹ 2500 / day
Suite    : ₹ 5000 / day
Deluxe   : ₹ 4000 / day
Family   : ₹ 3500 / day

HOW TO RUN
1. cd hotel_booking
2. python -m venv venv
3. .\venv\Scripts\Activate.ps1
4. pip install flask
5. python app.py
6. Open: http://127.0.0.1:5000

ROUTES
Route                      Method   Purpose
------------------------   ------   -----------------------
/                          GET      Show booking form
/booking                   GET      Show booking form
/booking/confirm           POST     Save + confirm
/bookings                  GET      List + search
/bookings/delete/<id>      POST     Delete booking

DATABASE SCHEMA
Table: bookings

Column           | Type     | Notes
-----------------|----------|-----------------
id               | INTEGER  | Primary key
guest_name       | TEXT     | Required
phone            | TEXT     | Required
email            | TEXT     | Optional
room_type        | TEXT     | Required
check_in         | TEXT     | Required (YYYY-MM-DD)
check_out        | TEXT     | Required (YYYY-MM-DD)
total_guests     | INTEGER  | Required
total_days       | INTEGER  | Auto-calculated
total_amount     | REAL     | Auto-calculated
special_request  | TEXT     | Optional
booked_at        | TEXT     | Auto timestamp

SAMPLE DATA
Guest Name      : Abhijit Suryawanshi
Phone           : 9876543210
Email           : abhijit@gmail.com
Room Type       : Deluxe
Check-in        : 2026-10-20
Check-out       : 2026-10-23
Total Guests    : 2
Total Days      : 3 (auto)
Total Amount    : ₹ 12000 (auto)
Special Request : Non-smoking room, extra bed

LEARNING OUTCOMES
- Date calculations with datetime module
- Auto-calculating totals
- Room rate dictionary
- Database INSERT with calculated values
- Flash messages for errors
- Form validation (check-out > check-in)

12-DAY CHALLENGE PROGRESS
Day 01  Employee Info       COMPLETED
Day 02  Student Info        COMPLETED
Day 03  Patient Info        COMPLETED
Day 04  Book Info           COMPLETED
Day 05  Vehicle Info        COMPLETED
Day 06  Hotel Booking       CURRENT
Day 07  Event Registration  UPCOMING
Day 08  Job Application     UPCOMING
Day 09  Bank Account        UPCOMING
Day 10  Restaurant Order    UPCOMING
Day 11  Mobile Shop         UPCOMING
Day 12  Movie Ticket        UPCOMING

AUTHOR
Name     : Abhijit Suryawanshi
Project  : ABHI IT PROJECTS
Year     : 2026

LICENSE
Free to use for learning purposes.


END OF README
