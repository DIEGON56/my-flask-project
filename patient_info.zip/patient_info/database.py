import sqlite3

DB_NAME = 'patients.db'


def get_connection():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
   
    conn = get_connection()
    conn.execute('''
        CREATE TABLE IF NOT EXISTS patients (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            name          TEXT NOT NULL,
            age           INTEGER NOT NULL,
            gender        TEXT NOT NULL,
            blood_group   TEXT,
            phone         TEXT NOT NULL,
            email         TEXT,
            address       TEXT,
            symptoms      TEXT NOT NULL,
            doctor        TEXT,
            registered_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()
    print("✅ Database initialized!")


# ---------- CREATE ----------
def add_patient(name, age, gender, blood_group, phone, email, address, symptoms, doctor):
    conn = get_connection()
    conn.execute('''
        INSERT INTO patients
        (name, age, gender, blood_group, phone, email, address, symptoms, doctor)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (name, age, gender, blood_group, phone, email, address, symptoms, doctor))
    conn.commit()
    conn.close()


# ---------- READ (all) ----------
def get_all_patients(search=None):
    conn = get_connection()
    if search:
        pattern = f'%{search}%'
        rows = conn.execute('''
            SELECT * FROM patients
            WHERE name LIKE ? OR phone LIKE ? OR doctor LIKE ?
            ORDER BY id DESC
        ''', (pattern, pattern, pattern)).fetchall()
    else:
        rows = conn.execute('SELECT * FROM patients ORDER BY id DESC').fetchall()
    conn.close()
    return rows


# ---------- READ (one) ----------
def get_patient(id):
    conn = get_connection()
    row = conn.execute('SELECT * FROM patients WHERE id = ?', (id,)).fetchone()
    conn.close()
    return row


# ---------- UPDATE ----------
def update_patient(id, name, age, gender, blood_group, phone, email, address, symptoms, doctor):
    conn = get_connection()
    conn.execute('''
        UPDATE patients
        SET name=?, age=?, gender=?, blood_group=?, phone=?,
            email=?, address=?, symptoms=?, doctor=?
        WHERE id=?
    ''', (name, age, gender, blood_group, phone, email, address, symptoms, doctor, id))
    conn.commit()
    conn.close()


# ---------- DELETE ----------
def delete_patient(id):
    conn = get_connection()
    conn.execute('DELETE FROM patients WHERE id = ?', (id,))
    conn.commit()
    conn.close()