from flask import Flask, render_template, request, redirect, url_for, flash
import database

web = Flask(__name__)
web.secret_key = 'patient-secret-key-2026'


database.init_db()



# HOME — Patients List

@web.route('/')
def index():
    search = request.args.get('search', '').strip()
    patients = database.get_all_patients(search or None)
    return render_template('index.html', patients=patients, search=search)



# ADD — Patient

@web.route('/add', methods=['GET', 'POST'])
def add_patient():
    if request.method == 'POST':
        database.add_patient(
            name        = request.form.get('name'),
            age         = int(request.form.get('age') or 0),
            gender      = request.form.get('gender'),
            blood_group = request.form.get('blood_group'),
            phone       = request.form.get('phone'),
            email       = request.form.get('email'),
            address     = request.form.get('address'),
            symptoms    = request.form.get('symptoms'),
            doctor      = request.form.get('doctor')
        )
        flash('Patient added successfully! 🏥', 'success')
        return redirect(url_for('index'))

    return render_template('add_patient.html')



# EDIT — Patient

@web.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit_patient(id):
    if request.method == 'POST':
        database.update_patient(
            id          = id,
            name        = request.form.get('name'),
            age         = int(request.form.get('age') or 0),
            gender      = request.form.get('gender'),
            blood_group = request.form.get('blood_group'),
            phone       = request.form.get('phone'),
            email       = request.form.get('email'),
            address     = request.form.get('address'),
            symptoms    = request.form.get('symptoms'),
            doctor      = request.form.get('doctor')
        )
        flash('Patient updated!', 'success')
        return redirect(url_for('index'))

    patient = database.get_patient(id)
    if not patient:
        flash('Patient not found!', 'error')
        return redirect(url_for('index'))

    return render_template('edit_patient.html', patient=patient)



# DELETE — Patient

@web.route('/delete/<int:id>', methods=['POST'])
def delete_patient(id):
    database.delete_patient(id)
    flash('Patient deleted.', 'success')
    return redirect(url_for('index'))


if __name__ == '__main__':
    web.run(debug=True)