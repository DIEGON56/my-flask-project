PATIENT INFORMATION FORM

Flask + HTML + CSS based simple patient registration system.



PROJECT DETAILS

Project Name : Patient Information Form
Day          : Day 3 of 12 Basic Projects Challenge
Created By   : Abhishek Suryawanshi
Date         : October 2026


ABOUT PROJECT

This is a simple Flask web application that allows users
to register patient information through an online form.
When the form is submitted, all the entered details are
displayed on a confirmation page.

This project is part of a 12-day learning challenge where
a new small project is built every day to practice Flask
fundamentals.


TECHNOLOGY USED

- Python 3.10
- Flask 3.0
- HTML5
- CSS3
- Jinja2 (templating)


FEATURES

- Clean and simple patient registration form
- Input validation using HTML5 (required fields)
- Dropdown selection for Gender, Blood Group, Doctor
- Text area for Address and Symptoms
- Confirmation page showing all entered details
- Empty fields displayed as "-" in confirmation
- Option to register another patient


FIELDS COLLECTED

1. Patient Name    (required)
2. Age             (required)
3. Gender          (required - dropdown)
4. Blood Group     (optional - dropdown)
5. Phone Number    (required)
6. Email           (optional)
7. Address         (optional)
8. Symptoms        (required)
9. Doctor Assigned (optional - dropdown)


FOLDER STRUCTURE

patient_info_db/
├── templates/
│   ├── base.html              ← NEW (shared layout)
│   ├── index.html             ← NEW (patients list)
│   ├── add_patient.html       ← form
│   ├── edit_patient.html      ← NEW (edit form)
│   └── patient_detail.html    ← optional (एक patient)
├── static/
│   └── style.css
├── app.py
├── database.py                ← NEW
├── patients.db                ← auto-create
└── venv/


HOW TO RUN

Step 1: Open terminal in the project folder

        cd patient_info

Step 2: Create virtual environment

        python -m venv venv

Step 3: Activate virtual environment

        Windows PowerShell:
            .\venv\Scripts\Activate.ps1

        Windows CMD:
            venv\Scripts\activate

        Mac/Linux:
            source venv/bin/activate

Step 4: Install Flask

        pip install flask

Step 5: Run the application

        python app.py

Step 6: Open in browser

        http://127.0.0.1:5000


ROUTES

Route                    Method     Purpose
----------------------   --------   -------------------------
/                        GET        Show patient form
/patient                 GET        Show patient form
/patient/confirm         GET        Show patient form
/patient/confirm         POST       Process form data


HOW IT WORKS

1. User opens http://127.0.0.1:5000/

2. Flask renders templates/patient_form.html
   (a form with all input fields)

3. User fills in patient details and clicks Submit

4. Browser sends POST request to /patient/confirm

5. Flask reads form data using request.form.get()

6. Flask renders templates/patient_confirm.html
   with all the collected data

7. Confirmation page displays all details in a table

8. User can click "Register Another Patient" to go back


LEARNING OUTCOMES

After completing this project, you will learn:

- How to create a Flask application
- How to define multiple routes in Flask
- How to use @app.route decorators
- How to handle GET and POST methods
- How to read form data using request.form.get()
- How to pass data from Flask to templates
- How to use Jinja2 variables {{ }}
- How to use conditions in Jinja2 ({{ value or "-" }})
- How to link CSS file using url_for()
- How to create HTML forms with different input types


INPUT TYPES USED

- text       : Patient name, phone, email
- number     : Age
- tel        : Phone number
- email      : Email address
- select     : Gender, Blood Group, Doctor
- textarea   : Address, Symptoms
- submit     : Form submission button


SAMPLE INPUT

Name         : Ramesh Patil
Age          : 35
Gender       : Male
Blood Group  : O+
Phone        : 9876543210
Email        : ramesh@gmail.com
Address      : 123 Main Street, Pune
Symptoms     : Fever, cough, headache
Doctor       : Dr. Sharma (General)


KNOWN LIMITATIONS

- Data is NOT saved (no database)
- Data is lost when the browser is refreshed
- No user authentication
- No validation on server side
- No edit or delete feature

Note: This is a learning project. A database version
will be built later in the challenge.


FUTURE IMPROVEMENTS

- Add SQLite database to save patient records
- Add list page to view all patients
- Add search functionality
- Add edit and delete options
- Add unique patient ID generation
- Add print / export to PDF option
- Add doctor appointment scheduling
- Add email confirmation to patient


NEXT PROJECT (Day 4)

Book Information Form
Fields: Book Title, Author, ISBN, Publisher, Category,
        Price, Year


12-DAY PROJECT CHALLENGE - PROGRESS

Day 01  Employee Info Form          COMPLETED
Day 02  Student Info Form           COMPLETED
Day 03  Patient Info Form           CURRENT
Day 04  Book Info Form              UPCOMING
Day 05  Vehicle Info Form           UPCOMING
Day 06  Hotel Booking Form          UPCOMING
Day 07  Event Registration Form     UPCOMING
Day 08  Job Application Form        UPCOMING
Day 09  Bank Account Form           UPCOMING
Day 10  Restaurant Order Form       UPCOMING
Day 11  Mobile Shop Form            UPCOMING
Day 12  Movie Ticket Form           UPCOMING


AUTHOR

Name    : Abhijit Suryawanshi
Course  : ABHI IT PROJECTS
Year    : 2026
Purpose : Learning Flask Web Development


LICENSE

Free to use for learning purposes.


END OF README
