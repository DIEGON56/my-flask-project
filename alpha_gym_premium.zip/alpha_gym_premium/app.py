from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3

app = Flask(__name__)
app.secret_key = "change-this-secret-key-before-deployment"

DATABASE = "gym.db"



# DATABASE CONNECTION

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn



# CREATE / UPDATE DATABASE TABLES

def create_table():
    conn = get_db_connection()

    # Contact Enquiries
    conn.execute("""
        CREATE TABLE IF NOT EXISTS enquiries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT NOT NULL,
            goal TEXT,
            message TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Members
    conn.execute("""
        CREATE TABLE IF NOT EXISTS members (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT NOT NULL,
            join_date TEXT NOT NULL,
            plan TEXT NOT NULL,
            total_fees REAL NOT NULL,
            fee_status TEXT NOT NULL DEFAULT 'Pending'
        )
    """)

    # Payments
    conn.execute("""
        CREATE TABLE IF NOT EXISTS payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            member_id INTEGER NOT NULL,
            amount REAL NOT NULL,
            payment_date TEXT NOT NULL,
            method TEXT,
            FOREIGN KEY (member_id) REFERENCES members(id)
        )
    """)

    # Migrate existing database: add fee_status if it does not exist yet.
    member_columns = [
        row["name"]
        for row in conn.execute("PRAGMA table_info(members)").fetchall()
    ]

    if "fee_status" not in member_columns:
        conn.execute("""
            ALTER TABLE members
            ADD COLUMN fee_status TEXT NOT NULL DEFAULT 'Pending'
        """)

    conn.commit()
    conn.close()


create_table()



# HOME PAGE


@app.route("/")
def home():
    return render_template("index.html", page="home")



# ABOUT PAGE


@app.route("/about")
def about():
    return render_template("about.html", page="about")



# PROGRAMS PAGE


@app.route("/programs")
def programs():
    return render_template("programs.html", page="programs")



# TRAINERS PAGE


@app.route("/trainers")
def trainers():
    return render_template("trainers.html", page="trainers")



# MEMBERSHIP PAGE


@app.route("/membership")
def membership():
    return render_template("membership.html", page="membership")



# CONTACT PAGE


@app.route("/contact", methods=["GET", "POST"])
def contact():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        phone = request.form.get("phone", "").strip()
        goal = request.form.get("goal", "").strip()
        message = request.form.get("message", "").strip()

        if not name or not phone:
            flash("Please enter your name and phone number.", "error")
        else:
            conn = get_db_connection()
            conn.execute("""
                INSERT INTO enquiries (name, phone, goal, message)
                VALUES (?, ?, ?, ?)
            """, (name, phone, goal, message))
            conn.commit()
            conn.close()

            flash(f"Thanks {name}! Your enquiry has been saved.", "success")
            return redirect(url_for("contact"))

    return render_template("contact.html", page="contact")



# MEMBERS MANAGEMENT PAGE


@app.route("/members")
def members():
    conn = get_db_connection()

    all_members = conn.execute("""
        SELECT
            m.*,
            COALESCE(SUM(p.amount), 0) AS paid,
            MAX(m.total_fees - COALESCE((
                SELECT SUM(p2.amount)
                FROM payments p2
                WHERE p2.member_id = m.id
            ), 0), 0) AS pending
        FROM members m
        LEFT JOIN payments p ON m.id = p.member_id
        GROUP BY m.id
        ORDER BY m.id DESC
    """).fetchall()

    conn.close()

    return render_template(
        "members.html",
        members=all_members,
        page="members"
    )



# ADD NEW MEMBER


@app.route("/members/add", methods=["POST"])
def add_member():
    name = request.form.get("name", "").strip()
    phone = request.form.get("phone", "").strip()
    join_date = request.form.get("join_date", "").strip()
    plan = request.form.get("plan", "").strip()

    try:
        total_fees = float(request.form.get("total_fees", 0))
    except (ValueError, TypeError):
        flash("Please enter a valid fees amount.", "error")
        return redirect(url_for("members"))

    if not name or not phone or not join_date or not plan:
        flash("Please fill all required member details.", "error")
        return redirect(url_for("members"))

    if total_fees <= 0:
        flash("Fees must be greater than zero.", "error")
        return redirect(url_for("members"))

    conn = get_db_connection()

    conn.execute("""
        INSERT INTO members
        (name, phone, join_date, plan, total_fees, fee_status)
        VALUES (?, ?, ?, ?, ?, 'Pending')
    """, (name, phone, join_date, plan, total_fees))

    conn.commit()
    conn.close()

    flash(f"Member {name} added successfully!", "success")
    return redirect(url_for("members"))



# MANUALLY UPDATE MEMBER FEE STATUS


@app.route("/members/update-status/<int:member_id>", methods=["POST"])
def update_fee_status(member_id):
    fee_status = request.form.get("fee_status", "").strip()
    allowed_statuses = ["Pending", "Partial", "Fully Paid"]

    if fee_status not in allowed_statuses:
        flash("Invalid fee status selected.", "error")
        return redirect(url_for("members"))

    conn = get_db_connection()

    member = conn.execute(
        "SELECT id FROM members WHERE id = ?",
        (member_id,)
    ).fetchone()

    if member is None:
        conn.close()
        flash("Member not found.", "error")
        return redirect(url_for("members"))

    conn.execute("""
        UPDATE members
        SET fee_status = ?
        WHERE id = ?
    """, (fee_status, member_id))

    conn.commit()
    conn.close()

    flash("Member fee status updated successfully.", "success")
    return redirect(url_for("members"))



# DELETE MEMBER


@app.route("/members/delete/<int:member_id>", methods=["POST"])
def delete_member(member_id):
    conn = get_db_connection()

    conn.execute("DELETE FROM payments WHERE member_id = ?", (member_id,))
    conn.execute("DELETE FROM members WHERE id = ?", (member_id,))

    conn.commit()
    conn.close()

    flash("Member deleted successfully.", "success")
    return redirect(url_for("members"))



# FEES MANAGEMENT PAGE


@app.route("/fees")
def fees():
    conn = get_db_connection()

    all_members = conn.execute("""
        SELECT *
        FROM members
        ORDER BY name ASC
    """).fetchall()

    fee_data = conn.execute("""
        SELECT
            m.id AS member_id,
            m.name,
            m.phone,
            m.total_fees,
            m.fee_status,
            COALESCE(SUM(p.amount), 0) AS paid
        FROM members m
        LEFT JOIN payments p ON m.id = p.member_id
        GROUP BY m.id
        ORDER BY m.name ASC
    """).fetchall()

    all_payments = conn.execute("""
        SELECT
            p.id,
            p.amount,
            p.payment_date,
            p.method,
            m.name AS member_name
        FROM payments p
        JOIN members m ON p.member_id = m.id
        ORDER BY p.id DESC
    """).fetchall()

    conn.close()

    updated_fee_data = []

    for row in fee_data:
        total = row["total_fees"] or 0
        paid = row["paid"] or 0
        pending = max(total - paid, 0)

        updated_fee_data.append({
            "member_id": row["member_id"],
            "name": row["name"],
            "phone": row["phone"],
            "total_fees": total,
            "paid": paid,
            "pending": pending,
            "status": row["fee_status"]
        })

    return render_template(
        "fees.html",
        members=all_members,
        fee_data=updated_fee_data,
        payments=all_payments,
        page="fees"
    )



# ADD MEMBER PAYMENT


@app.route("/fees/add", methods=["POST"])
def add_payment():
    member_id = request.form.get("member_id", "").strip()
    payment_date = request.form.get("payment_date", "").strip()
    method = request.form.get("method", "").strip()

    try:
        amount = float(request.form.get("amount", 0))
    except (ValueError, TypeError):
        flash("Please enter a valid payment amount.", "error")
        return redirect(url_for("fees"))

    if not member_id or not payment_date:
        flash("Please select a member and payment date.", "error")
        return redirect(url_for("fees"))

    if amount <= 0:
        flash("Payment amount must be greater than zero.", "error")
        return redirect(url_for("fees"))

    conn = get_db_connection()

    member = conn.execute(
        "SELECT * FROM members WHERE id = ?",
        (member_id,)
    ).fetchone()

    if member is None:
        conn.close()
        flash("Selected member does not exist.", "error")
        return redirect(url_for("fees"))

    result = conn.execute("""
        SELECT COALESCE(SUM(amount), 0) AS paid
        FROM payments
        WHERE member_id = ?
    """, (member_id,)).fetchone()

    already_paid = result["paid"] or 0
    pending = member["total_fees"] - already_paid

    if pending <= 0:
        conn.close()
        flash("This member has already paid the full fees.", "error")
        return redirect(url_for("fees"))

    if amount > pending:
        conn.close()
        flash(
            f"Payment exceeds pending fees of Rs. {pending:.2f}.",
            "error"
        )
        return redirect(url_for("fees"))

    conn.execute("""
        INSERT INTO payments (member_id, amount, payment_date, method)
        VALUES (?, ?, ?, ?)
    """, (member_id, amount, payment_date, method))

    # Update status based on actual payment record.
    new_paid = already_paid + amount

    if new_paid >= member["total_fees"]:
        new_status = "Fully Paid"
    elif new_paid > 0:
        new_status = "Partial"
    else:
        new_status = "Pending"

    conn.execute("""
        UPDATE members
        SET fee_status = ?
        WHERE id = ?
    """, (new_status, member_id))

    conn.commit()
    conn.close()

    flash("Payment saved successfully!", "success")
    return redirect(url_for("fees"))



# RUN FLASK APPLICATION


if __name__ == "__main__":
    app.run(debug=True)
