ALPHA GYM — FLASK WEBSITE


PROJECT STRUCTURE

alpha_gym_premium/
│ app.py
│ requirements.txt
│ README_MR.txt
├── templates/
│   ├── base.html       (For pages common navbar + footer)
│   ├── index.html      (Home page)
│   ├── about.html      (About page)
│   ├── programs.html   (Programs page)
│   ├── trainers.html   (Trainers page)
│   ├── membership.html (Membership page)
│   └── contact.html    (Contact / enquiry form)
└── static/
    ├── css/style.css
    ├── js/main.js
    └── images/gym-bg.png (Alpha Gym PNG image)

HOW TO RUN ON WINDOWS 

1. ZIP extract.
2. VS Code AND OPEN  alpha_gym_premium folder 
3. Terminal

   python -m venv venv
   venv\\Scripts\\activate
   pip install -r requirements.txt
   python app.py

4. OPEN Browser :
   http://127.0.0.1:5000

