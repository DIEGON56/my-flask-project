from flask import Flask, render_template, request, redirect, url_for, flash
import database

web = Flask(__name__)
web.secret_key = 'vehicle-secret-key-2026'

database.init_db()



# ROUTE 1 — Vehicle Form

@web.route('/')
@web.route('/vehicle')
def vehicle_form():
    return render_template('vehicle_form.html')



# ROUTE 2 — Confirmation + Save

@web.route('/vehicle/confirm', methods=['GET', 'POST'])
def vehicle_confirm():
    if request.method == 'POST':
        owner_name       = request.form.get("owner_name")
        vehicle_number   = request.form.get("vehicle_number")
        vehicle_type     = request.form.get("vehicle_type")
        brand            = request.form.get("brand")
        model            = request.form.get("model")
        year             = request.form.get("year")
        color            = request.form.get("color")
        fuel_type        = request.form.get("fuel_type")
        insurance_expiry = request.form.get("insurance_expiry")
        chassis_number   = request.form.get("chassis_number")

        # Save to database
        database.add_vehicle(
            owner_name       = owner_name,
            vehicle_number   = vehicle_number,
            vehicle_type     = vehicle_type,
            brand            = brand,
            model            = model,
            year             = int(year) if year else None,
            color            = color,
            fuel_type        = fuel_type,
            insurance_expiry = insurance_expiry,
            chassis_number   = chassis_number
        )

        flash('Vehicle successfully save झाली! 🚗', 'success')

        return render_template(
            'vehicle_confirm.html',
            owner_name=owner_name,
            vehicle_number=vehicle_number,
            vehicle_type=vehicle_type,
            brand=brand,
            model=model,
            year=year,
            color=color,
            fuel_type=fuel_type,
            insurance_expiry=insurance_expiry,
            chassis_number=chassis_number
        )

    return render_template('vehicle_form.html')



# ROUTE 3 — Vehicles List

@web.route('/vehicles')
def vehicles_list():
    search = request.args.get('search', '').strip()
    vehicles = database.get_all_vehicles(search or None)
    return render_template('vehicles_list.html', vehicles=vehicles, search=search)



# ROUTE 4 — Delete Vehicle

@web.route('/vehicles/delete/<int:id>', methods=['POST'])
def delete_vehicle(id):
    database.delete_vehicle(id)
    flash('Vehicle deleted.', 'success')
    return redirect(url_for('vehicles_list'))


if __name__ == '__main__':
    web.run(debug=True)