import sqlite3

DB_NAME = 'vehicles.db'


def get_connection():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """vehicles table created here."""
    conn = get_connection()
    conn.execute('''
        CREATE TABLE IF NOT EXISTS vehicles (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            owner_name       TEXT NOT NULL,
            vehicle_number   TEXT NOT NULL,
            vehicle_type     TEXT NOT NULL,
            brand            TEXT,
            model            TEXT,
            year             INTEGER,
            color            TEXT,
            fuel_type        TEXT,
            insurance_expiry TEXT,
            chassis_number   TEXT,
            added_at         TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()
    print("✅ Vehicles database initialized!")


# ---------- CREATE ----------
def add_vehicle(owner_name, vehicle_number, vehicle_type, brand, model,
                year, color, fuel_type, insurance_expiry, chassis_number):
    conn = get_connection()
    conn.execute('''
        INSERT INTO vehicles
        (owner_name, vehicle_number, vehicle_type, brand, model,
         year, color, fuel_type, insurance_expiry, chassis_number)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (owner_name, vehicle_number, vehicle_type, brand, model,
          year, color, fuel_type, insurance_expiry, chassis_number))
    conn.commit()
    conn.close()


# ---------- READ (all) ----------
def get_all_vehicles(search=None):
    conn = get_connection()
    if search:
        pattern = f'%{search}%'
        rows = conn.execute('''
            SELECT * FROM vehicles
            WHERE owner_name LIKE ? OR vehicle_number LIKE ? OR brand LIKE ?
            ORDER BY id DESC
        ''', (pattern, pattern, pattern)).fetchall()
    else:
        rows = conn.execute('SELECT * FROM vehicles ORDER BY id DESC').fetchall()
    conn.close()
    return rows


# ---------- READ (one) ----------
def get_vehicle(id):
    conn = get_connection()
    row = conn.execute('SELECT * FROM vehicles WHERE id = ?', (id,)).fetchone()
    conn.close()
    return row


# ---------- DELETE ----------
def delete_vehicle(id):
    conn = get_connection()
    conn.execute('DELETE FROM vehicles WHERE id = ?', (id,))
    conn.commit()
    conn.close()