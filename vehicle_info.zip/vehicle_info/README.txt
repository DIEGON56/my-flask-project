
VEHICLE INFORMATION SYSTEM (WITH DATABASE)

Flask + SQLite based vehicle information system.



PROJECT DETAILS

Project Name : Vehicle Information System
Type         : Type B (Database version)
Day          : Day 5 of 12 Basic Projects Challenge
Created By   : Abhijit Suryawanshi
Date         : October 2026


ABOUT PROJECT

A Flask web application where users can add vehicle
information through an online form. All data is saved
permanently in an SQLite database. Users can view all
vehicles, search through them, and delete entries.


TECHNOLOGY USED

- Python 3.10
- Flask 3.0
- SQLite (database)
- HTML5
- CSS3
- Jinja2


FEATURES

- Add new vehicle with full details
- Save data permanently in SQLite database
- Confirmation page after saving
- View all vehicles in a table
- Search vehicles by owner, number, or brand
- Delete vehicles
- Flash messages
- Data persists after server restart


FIELDS COLLECTED

1. Owner Name         (required)
2. Vehicle Number     (required)
3. Vehicle Type       (required - dropdown)
4. Brand              (optional)
5. Model              (optional)
6. Manufacturing Year (optional)
7. Color              (optional)
8. Fuel Type          (optional - dropdown)
9. Insurance Expiry   (optional - date)
10. Chassis Number    (optional)


FOLDER STRUCTURE

vehicle_info/
|
|-- app.py                     (Flask app - 4 routes)
|-- database.py                (SQLite functions)
|-- requirements.txt
|-- README.txt
|-- vehicles.db                (auto created)
|
|-- templates/
|   |-- vehicle_form.html
|   |-- vehicle_confirm.html
|   |-- vehicles_list.html
|
|-- static/
|   |-- style.css
|
|-- venv/


HOW TO RUN

1. cd vehicle_info
2. python -m venv venv
3. .\venv\Scripts\Activate.ps1
4. pip install flask
5. python app.py
6. Open: http://127.0.0.1:5000


ROUTES

Route                       Method   Purpose
-------------------------   ------   ---------------------
/                           GET      Show vehicle form
/vehicle                    GET      Show vehicle form
/vehicle/confirm            POST     Save + confirm
/vehicles                   GET      List vehicles + search
/vehicles/delete/<id>       POST     Delete vehicle


DATABASE SCHEMA

Table: vehicles

Column             | Type     | Notes
-------------------|----------|------------------
id                 | INTEGER  | Primary key
owner_name         | TEXT     | Required
vehicle_number     | TEXT     | Required
vehicle_type       | TEXT     | Required
brand              | TEXT     | Optional
model              | TEXT     | Optional
year               | INTEGER  | Optional
color              | TEXT     | Optional
fuel_type          | TEXT     | Optional
insurance_expiry   | TEXT     | Optional
chassis_number     | TEXT     | Optional
added_at           | TEXT     | Auto timestamp

Database file: vehicles.db (auto-created)


SAMPLE DATA

Owner Name       : Abhijit Suryawanshi
Vehicle Number   : MH 12 AB 1234
Vehicle Type     : Car
Brand            : Maruti Suzuki
Model            : Swift
Year             : 2022
Color            : White
Fuel Type        : Petrol
Insurance Expiry : 2027-06-15
Chassis Number   : MAT625181JPD12345


LEARNING OUTCOMES

- Flask + SQLite integration
- CREATE TABLE, INSERT, SELECT, DELETE
- SQL placeholders (?) for safety
- row_factory = sqlite3.Row
- Flash messages
- File separation (app.py + database.py)
- Search functionality
- Data persistence


12-DAY CHALLENGE PROGRESS

Day 01  Employee Info       COMPLETED
Day 02  Student Info        COMPLETED
Day 03  Patient Info        COMPLETED
Day 04  Book Info           COMPLETED
Day 05  Vehicle Info        CURRENT
Day 06  Hotel Booking       UPCOMING
Day 07  Event Registration  UPCOMING
Day 08  Job Application     UPCOMING
Day 09  Bank Account        UPCOMING
Day 10  Restaurant Order    UPCOMING
Day 11  Mobile Shop         UPCOMING
Day 12  Movie Ticket        UPCOMING


AUTHOR

Name     : Abhijit Suryawanshi
Project  : ABHI IT PROJECTS
Year     : 2026


LICENSE

Free to use for learning purposes.


END OF README
