from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from pathlib import Path

app = Flask(__name__)
app.config["SECRET_KEY"] = "blood-bank-secret-key-change-me"
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///bloodbank.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)

class Donor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(120), nullable=False)
    age = db.Column(db.Integer, nullable=False)
    gender = db.Column(db.String(20), nullable=False)
    blood_group = db.Column(db.String(10), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    city = db.Column(db.String(80), nullable=False)
    last_donation = db.Column(db.String(20), nullable=True)
    available = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class ContactMessage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(20), nullable=True)
    message = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

with app.app_context():
    db.create_all()

@app.route("/")
def home():
    donors = Donor.query.filter_by(available=True).all()
    groups = {}
    for donor in donors:
        groups[donor.blood_group] = groups.get(donor.blood_group, 0) + 1
    stats = {
        "donors": Donor.query.count(),
        "available": len(donors),
        "groups": len(groups),
        "requests": 0
    }
    return render_template("index.html", stats=stats, groups=groups)

@app.route("/become-donor", methods=["GET", "POST"])
def become_donor():
    if request.method == "POST":
        donor = Donor(
            full_name=request.form["full_name"].strip(),
            age=int(request.form["age"]),
            gender=request.form["gender"],
            blood_group=request.form["blood_group"],
            phone=request.form["phone"].strip(),
            email=request.form["email"].strip(),
            city=request.form["city"].strip(),
            last_donation=request.form.get("last_donation", "").strip(),
            available=True
        )
        db.session.add(donor)
        db.session.commit()
        flash("Donor registration successful! Thank you for saving lives.", "success")
        return redirect(url_for("registered_donor"))
    return render_template("become_donor.html")

@app.route("/registered-donor")
def registered_donor():
    donors = Donor.query.order_by(Donor.created_at.desc()).all()
    return render_template("registered_donor.html", donors=donors)

@app.route("/available-blood")
def available_blood():
    selected = request.args.get("group", "")
    query = Donor.query.filter_by(available=True)
    if selected:
        query = query.filter_by(blood_group=selected)
    donors = query.order_by(Donor.blood_group, Donor.full_name).all()
    counts = {}
    for donor in Donor.query.filter_by(available=True).all():
        counts[donor.blood_group] = counts.get(donor.blood_group, 0) + 1
    return render_template("available_blood.html", donors=donors, counts=counts, selected=selected)

@app.route("/search")
def search():
    q = request.args.get("q", "").strip()
    donors = []
    if q:
        donors = Donor.query.filter(
            db.or_(
                Donor.full_name.ilike(f"%{q}%"),
                Donor.city.ilike(f"%{q}%"),
                Donor.blood_group.ilike(f"%{q}%")
            ),
            Donor.available == True
        ).all()
    return render_template("search.html", donors=donors, q=q)

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/blood-camps")
def blood_camps():
    return render_template("blood_camps.html")

@app.route("/contact", methods=["GET", "POST"])
def contact():
    if request.method == "POST":
        msg = ContactMessage(
            name=request.form["name"].strip(),
            email=request.form["email"].strip(),
            phone=request.form.get("phone", "").strip(),
            message=request.form["message"].strip()
        )
        db.session.add(msg)
        db.session.commit()
        flash("Your message has been sent successfully.", "success")
        return redirect(url_for("contact"))
    return render_template("contact.html")

@app.route("/api/stats")
def api_stats():
    donors = Donor.query.filter_by(available=True).all()
    counts = {}
    for donor in donors:
        counts[donor.blood_group] = counts.get(donor.blood_group, 0) + 1
    return jsonify({"total_donors": Donor.query.count(), "available": len(donors), "groups": counts})

if __name__ == "__main__":
    app.run(debug=True)
