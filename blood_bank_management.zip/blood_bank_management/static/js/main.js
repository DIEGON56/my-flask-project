document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.getElementById("menuToggle");
  const nav = document.getElementById("mainNav");
  if (toggle && nav) toggle.addEventListener("click", () => nav.classList.toggle("open"));

  document.querySelectorAll("input[type='tel'], input[name='phone']").forEach(input => {
    input.addEventListener("input", () => input.value = input.value.replace(/\D/g, "").slice(0, 10));
  });

  const counters = document.querySelectorAll(".counter");
  counters.forEach(counter => {
    const target = Number(counter.textContent) || 0;
    let current = 0;
    if (target === 0) return;
    const step = Math.max(1, Math.ceil(target / 25));
    const timer = setInterval(() => {
      current += step;
      if (current >= target) { current = target; clearInterval(timer); }
      counter.textContent = current;
    }, 35);
  });
});
