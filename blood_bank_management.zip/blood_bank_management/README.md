# Blood Bank Management System

Professional Flask web application with:
- HTML + CSS + JavaScript frontend
- Python Flask backend
- SQLite database
- Become a Donor registration
- Registered Donor directory
- Available Blood Group search
- Donor search
- Contact Us form
- WhatsApp floating chat button
- Responsive mobile/desktop design
- Blood donation camps page
- About and awareness sections

## Run on Windows

1. Open the project folder in VS Code.
2. Open Terminal / PowerShell.
3. Create virtual environment:

```powershell
python -m venv venv
```

4. Activate it:

```powershell
venv\Scripts\activate
```

5. Install packages:

```powershell
pip install -r requirements.txt
```

6. Start the application:

```powershell
python app.py
```

7. Open:
http://127.0.0.1:5000

The SQLite database `bloodbank.db` will be created automatically.

## WhatsApp

The floating WhatsApp button uses:
9209122095

The code is in `templates/base.html`. If the number is changed later, update the `WHATSAPP_NUMBER` value there.

## Important

This is a college/project application. Real blood inventory should be connected to verified blood-bank records and appropriate authentication/security before production use.
